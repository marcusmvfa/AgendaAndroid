package alura.com.br.ui.activity;

interface ConstantesActivities {
    String CHAVE_ALUNO = "aluno";
}
