package alura.com.br;

import android.app.Application;

import alura.com.br.dao.AlunoDAO;
import alura.com.br.model.Aluno;

@SuppressWarnings("WeakerAccess")
public class AgendaApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        insereAlunosTeste();
    }

    private void insereAlunosTeste() {
        AlunoDAO dao = new AlunoDAO();
        dao.salva(new Aluno("Marcus", "4598449756", "marcuspa3@gmail.com"));
        dao.salva(new Aluno("Teste", "4598746521", "teste@gmail.com"));
    }
}
